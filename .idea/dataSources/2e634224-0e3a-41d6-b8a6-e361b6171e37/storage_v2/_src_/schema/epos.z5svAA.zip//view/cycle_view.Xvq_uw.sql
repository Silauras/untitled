create view cycle_view as
select `p`.`plan_id`         AS `plan_id`,
       `cy`.`cycle_id`       AS `cycle_id`,
       `cy`.`cycle_type`     AS `cycle_type`,
       `cy`.`cyle_name`      AS `cyle_name`,
       `cy`.`acad_degree_id` AS `acad_degree_id`
from ((((`epos`.`plan` `p` join `epos`.`plan_version` `pv` on (((`pv`.`plan_id` = `p`.`plan_id`) and
                                                                (`pv`.`effective` = (select max(`pv_max`.`effective`)
                                                                                     from `epos`.`plan_version` `pv_max`
                                                                                     where ((`pv`.`plan_id` = `pv_max`.`plan_id`) and
                                                                                            (`pv_max`.`effective` <= now())))) and
                                                                (`p`.`deleted` > now())))) join `epos`.`edu_proposition` `ep` on ((`ep`.`edu_proposition_id` = `pv`.`edu_proposition_id`))) join `epos`.`acad_degree` `ad` on ((`ad`.`acad_degree_id` = `ep`.`acad_degree_id`)))
         join `epos`.`cycle` `cy` on ((`cy`.`acad_degree_id` = `ad`.`acad_degree_id`)))
order by `p`.`plan_id`, `cy`.`acad_degree_id`, `cy`.`cycle_type`, `cy`.`cyle_name`;

