create
    definer = root@localhost function getCourse(semester int) returns int
BEGIN
	if ISNULL(semester) then 
		set semester = 0;
	end if;

	RETURN ((semester + 1) div 2);
END;

