create view department_view as
select `dv`.`department_id`     AS `department_id`,
       `dv`.`department_number` AS `department_number`,
       `dv`.`full_name`         AS `full_name`,
       `dv`.`short_name`        AS `short_name`,
       `dv`.`details`           AS `details`,
       `dv`.`faculty_id`        AS `faculty_id`
from (`epos`.`department` `d`
         join `epos`.`department_version` `dv` on (((`dv`.`department_id` = `d`.`department_id`) and
                                                    (`dv`.`effective` = (select max(`dv_max`.`effective`)
                                                                         from `epos`.`department_version` `dv_max`
                                                                         where ((`dv`.`department_id` = `dv_max`.`department_id`) and
                                                                                (`dv_max`.`effective` <= now())))) and
                                                    (`d`.`deleted` > now()))))
order by `dv`.`department_number`;

