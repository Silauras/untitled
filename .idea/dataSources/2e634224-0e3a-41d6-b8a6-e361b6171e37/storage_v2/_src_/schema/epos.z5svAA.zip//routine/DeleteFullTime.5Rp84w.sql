create
    definer = root@localhost procedure DeleteFullTime(IN vfull_time_id int, OUT delete_state int)
BEGIN
    DECLARE full_time_exists integer default 0;
    DECLARE updated_rows integer default 0;

    START TRANSACTION;
        set full_time_exists = IsFullTimeExistsById(vfull_time_id);

		if full_time_exists = 1 then
			update full_time
			set deleted = now()
			where full_time_id = vfull_time_id;

			set delete_state = ROW_COUNT();

			IF delete_state = 1 THEN
				COMMIT;
			 ELSE
				ROLLBACK;
			END IF;
		end if;
END;

