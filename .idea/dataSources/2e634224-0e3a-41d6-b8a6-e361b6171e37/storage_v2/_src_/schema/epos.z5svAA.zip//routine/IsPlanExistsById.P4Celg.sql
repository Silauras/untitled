create
    definer = root@localhost function IsPlanExistsById(vplan_id int) returns int
BEGIN
	declare plan_exists integer default 0;

    select count(plan_id)
    into plan_exists
    from plan
    where plan_id = vplan_id;

	IF plan_exists> 0 THEN
		return 1;
	else
		return 0;
	end if;
END;

