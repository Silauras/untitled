create
    definer = root@localhost procedure CopyFullTimePlan(IN vplan_id int, IN vplan_name varchar(255), IN vready int,
                                                        IN vlockedout int, IN vstart_year_id int,
                                                        IN vedu_proposition_id int, IN vedu_calendar_id int,
                                                        OUT copy_state int)
BEGIN
    DECLARE plan_exists integer default 0;
	DECLARE new_plan_id integer default 0;

    DECLARE plan_name_mod integer default 1;

	DECLARE last_inserted_id integer default 0;

    declare done integer default 0;

  	DECLARE updated_rows integer default 0;

DECLARE vterm SMALLINT;
DECLARE vcredits decimal(10,2);
DECLARE vlecture_per_week_first SMALLINT;
DECLARE vlecture_per_week_second SMALLINT;
DECLARE vlab_work_per_week_first SMALLINT;
DECLARE vlab_work_per_week_second SMALLINT;
DECLARE vpractical_work_per_week_first SMALLINT;
DECLARE vpractical_work_per_week_second SMALLINT;
DECLARE vcalc_graph_work SMALLINT;
DECLARE vcalc_work SMALLINT;
DECLARE vcontrol_work SMALLINT;
DECLARE vcourse_work SMALLINT;
DECLARE vcourse_project SMALLINT;
DECLARE vexam SMALLINT;
DECLARE vgraded_test SMALLINT;
DECLARE vtest SMALLINT;
DECLARE vlecture_hours_first SMALLINT;
DECLARE vlecture_hours_second SMALLINT;
DECLARE vlab_work_hours_first SMALLINT;
DECLARE vlab_work_hours_second SMALLINT;
DECLARE vpractical_work_hours_first SMALLINT;
DECLARE vpractical_work_hours_second SMALLINT;
DECLARE vlecture_hours SMALLINT;
DECLARE vlab_work_hours SMALLINT;
DECLARE vpractical_work_hours SMALLINT;
DECLARE vcredit_hours SMALLINT;
DECLARE vacademic_hours SMALLINT;
DECLARE vindependent_work_hours SMALLINT;
DECLARE vcycle_id INT;
DECLARE vdiscipline_id INT;
DECLARE vdepartment_reader_id INT;
DECLARE vmandatory_lock INT;


    declare curfull_time_version cursor for
		select
		term, credits, lecture_per_week_first, lecture_per_week_second, lab_work_per_week_first, lab_work_per_week_second, practical_work_per_week_first, practical_work_per_week_second, calc_graph_work, calc_work, control_work, course_work, course_project, exam, graded_test, test, lecture_hours_first, lecture_hours_second, lab_work_hours_first, lab_work_hours_second, practical_work_hours_first, practical_work_hours_second, lecture_hours, lab_work_hours, practical_work_hours, credit_hours, academic_hours, independent_work_hours, cycle_id, discipline_id, department_reader_id, mandatory_lock
		from
		full_time ft
			inner join full_time_version ftv
				on ftv.full_time_id = ft.full_time_id
					and ftv.effective =
						(select max(effective)
							from full_time_version ftv_max
							where ftv.full_time_id = ftv_max.full_time_id
								and ftv_max.effective <=now())
					and ft.deleted > now()
		where ft.plan_id = vplan_id;
	declare continue handler for not found set done=1;

    set copy_state = 0;
    START TRANSACTION;

        set plan_exists = IsPlanExistsById(vplan_id);

        if plan_exists = 1 then
			-- Insert data fro plan
			insert into plan (created, deleted)
			values(default, default);

			-- get last inserted id for plan
			SET new_plan_id = LAST_INSERT_ID();

			-- insert dependent data for plan_version
			IF new_plan_id > 0 THEN
			INSERT INTO plan_version(plan_id, effective, created, plan_name, ready, lockedout, start_year_id, edu_proposition_id, edu_calendar_id)
				VALUES(new_plan_id, default, default, PlanNameMod(vplan_name, "[C]"), vready, vlockedout, vstart_year_id, vedu_proposition_id, vedu_calendar_id);

                    set done = 0;

                open curfull_time_version;
                cursorLoop: loop
					fetch curfull_time_version into
                    vterm, vcredits, vlecture_per_week_first, vlecture_per_week_second, vlab_work_per_week_first, vlab_work_per_week_second, vpractical_work_per_week_first, vpractical_work_per_week_second, vcalc_graph_work, vcalc_work, vcontrol_work, vcourse_work, vcourse_project, vexam, vgraded_test, vtest, vlecture_hours_first, vlecture_hours_second, vlab_work_hours_first, vlab_work_hours_second, vpractical_work_hours_first, vpractical_work_hours_second, vlecture_hours, vlab_work_hours, vpractical_work_hours, vcredit_hours, vacademic_hours, vindependent_work_hours, vcycle_id, vdiscipline_id, vdepartment_reader_id, vmandatory_lock;

					if done = 1 then leave cursorLoop; end if;

                    insert into full_time (created, deleted, plan_id)
					values(default, default, new_plan_id);

					-- get last inserted id for full_time
					SET last_inserted_id = LAST_INSERT_ID();

                    insert into full_time_version (full_time_id, effective, created, term, credits, lecture_per_week_first, lecture_per_week_second, lab_work_per_week_first, lab_work_per_week_second, practical_work_per_week_first, practical_work_per_week_second, calc_graph_work, calc_work, control_work, course_work, course_project, exam, graded_test, test, lecture_hours_first, lecture_hours_second, lab_work_hours_first, lab_work_hours_second, practical_work_hours_first, practical_work_hours_second, lecture_hours, lab_work_hours, practical_work_hours, credit_hours, academic_hours, independent_work_hours, cycle_id, discipline_id, department_reader_id)
                    values (last_inserted_id, default, default, vterm, vcredits, vlecture_per_week_first, vlecture_per_week_second, vlab_work_per_week_first, vlab_work_per_week_second, vpractical_work_per_week_first, vpractical_work_per_week_second, vcalc_graph_work, vcalc_work, vcontrol_work, vcourse_work, vcourse_project, vexam, vgraded_test, vtest, vlecture_hours_first, vlecture_hours_second, vlab_work_hours_first, vlab_work_hours_second, vpractical_work_hours_first, vpractical_work_hours_second, vlecture_hours, vlab_work_hours, vpractical_work_hours, vcredit_hours, vacademic_hours, vindependent_work_hours, vcycle_id, vdiscipline_id, vdepartment_reader_id);

                    set copy_state = copy_state + ROW_COUNT();

                end loop cursorLoop;
                close curfull_time_version;

				IF copy_state > 0 THEN
					COMMIT;
				 ELSE
					ROLLBACK;
				END IF;

			end if;
        end if;

END;

