create
    definer = root@localhost procedure DeletePlan(IN vplan_id int, OUT delete_state int)
BEGIN
    DECLARE plan_exists integer default 0;
    DECLARE updated_rows integer default 0;

    START TRANSACTION;
        set plan_exists = IsPlanExistsById(vplan_id);
		if plan_exists = 1 then
            set delete_state = 0;

			update plan
			set deleted = now()
			where plan_id = vplan_id;

			set delete_state = ROW_COUNT();

			IF delete_state = 1 THEN
				COMMIT;
			 ELSE
				ROLLBACK;
			END IF;
		end if;
END;

