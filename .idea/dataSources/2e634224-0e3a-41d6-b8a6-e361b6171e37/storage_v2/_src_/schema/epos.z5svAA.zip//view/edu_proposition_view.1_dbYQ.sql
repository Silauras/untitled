create view edu_proposition_view as
select `ep`.`edu_proposition_id` AS `edu_proposition_edu_proposition_id`,
       `ep`.`edu_span`           AS `edu_proposition_edu_span`,
       `ep`.`edu_type`           AS `edu_proposition_edu_type`,
       `ep`.`student_type`       AS `edu_proposition_student_type`,
       `ep`.`edu_language`       AS `edu_proposition_edu_language`,
       `ep`.`enrollment_number`  AS `edu_proposition_enrollment_number`,
       `ep`.`enrollment_type`    AS `edu_proposition_enrollment_type`,
       `ep`.`staff_coeff`        AS `edu_proposition_staff_coeff`,
       `ep`.`department_id`      AS `edu_proposition_department_id`,
       `ep`.`acad_degree_id`     AS `edu_proposition_acad_degree_id`,
       `ep`.`direction_id`       AS `edu_proposition_direction_id`,
       `ep`.`speciality_id`      AS `edu_proposition_speciality_id`,
       `ep`.`edu_program_id`     AS `edu_proposition_edu_program_id`,
       `dv`.`department_id`      AS `department_version_department_id`,
       `dv`.`effective`          AS `department_version_effective`,
       `dv`.`created`            AS `department_version_created`,
       `dv`.`department_number`  AS `department_version_department_number`,
       `dv`.`full_name`          AS `department_version_full_name`,
       `dv`.`short_name`         AS `department_version_short_name`,
       `dv`.`details`            AS `department_version_details`,
       `dv`.`faculty_id`         AS `department_version_faculty_id`,
       `fv`.`faculty_id`         AS `faculty_version_faculty_id`,
       `fv`.`effective`          AS `faculty_version_effective`,
       `fv`.`created`            AS `faculty_version_created`,
       `fv`.`faculty_number`     AS `faculty_version_faculty_number`,
       `fv`.`full_name`          AS `faculty_version_full_name`,
       `fv`.`short_name`         AS `faculty_version_short_name`,
       `fv`.`details`            AS `faculty_version_details`,
       `ad`.`acad_degree_id`     AS `acad_degree_acad_degree_id`,
       `ad`.`full_name`          AS `acad_degree_full_name`,
       `ad`.`short_name`         AS `acad_degree_short_name`,
       `ad`.`details`            AS `acad_degree_details`,
       `dir`.`direction_id`      AS `direction_direction_id`,
       `dir`.`direction_code`    AS `direction_direction_code`,
       `dir`.`full_name`         AS `direction_full_name`,
       `dir`.`short_name`        AS `direction_short_name`,
       `dir`.`details`           AS `direction_details`,
       `spec`.`speciality_id`    AS `speciality_speciality_id`,
       `spec`.`speciality_code`  AS `speciality_speciality_code`,
       `spec`.`full_name`        AS `speciality_full_name`,
       `spec`.`short_name`       AS `speciality_short_name`,
       `spec`.`details`          AS `speciality_details`,
       `eprog`.`edu_program_id`  AS `edu_program_edu_program_id`,
       `eprog`.`full_name`       AS `edu_program_full_name`,
       `eprog`.`short_name`      AS `edu_program_short_name`,
       `eprog`.`details`         AS `edu_program_details`
from ((((((((`epos`.`edu_proposition` `ep` join `epos`.`department` `d` on ((`d`.`department_id` = `ep`.`department_id`))) join `epos`.`department_version` `dv` on ((
        (`dv`.`department_id` = `d`.`department_id`) and (`dv`.`effective` = (select max(`dv_max`.`effective`)
                                                                              from `epos`.`department_version` `dv_max`
                                                                              where ((`dv`.`department_id` = `dv_max`.`department_id`) and
                                                                                     (`dv_max`.`effective` <= now())))) and
        (`d`.`deleted` > now())))) join `epos`.`faculty` `f` on ((`f`.`faculty_id` = `dv`.`faculty_id`))) join `epos`.`faculty_version` `fv` on ((
        (`fv`.`faculty_id` = `f`.`faculty_id`) and (`fv`.`effective` = (select max(`fv_max`.`effective`)
                                                                        from `epos`.`faculty_version` `fv_max`
                                                                        where ((`fv`.`faculty_id` = `fv_max`.`faculty_id`) and
                                                                               (`fv_max`.`effective` <= now())))) and
        (`f`.`deleted` > now())))) join `epos`.`acad_degree` `ad` on ((`ad`.`acad_degree_id` = `ep`.`acad_degree_id`))) join `epos`.`direction` `dir` on ((`dir`.`direction_id` = `ep`.`direction_id`))) join `epos`.`speciality` `spec` on ((`spec`.`speciality_id` = `ep`.`speciality_id`)))
         join `epos`.`edu_program` `eprog` on ((`eprog`.`edu_program_id` = `ep`.`edu_program_id`)))
order by `ep`.`student_type`, `ep`.`edu_language`, `ep`.`enrollment_number`, `ep`.`enrollment_type`,
         `fv`.`faculty_number`, `dv`.`department_number`, `ad`.`full_name`, `dir`.`direction_code`, `dir`.`full_name`,
         `spec`.`speciality_code`, `spec`.`full_name`, `ep`.`edu_span`, `eprog`.`full_name`;

