create view edu_calendar_body_view as
select `p`.`plan_id`                       AS `plan_id`,
       `ecb`.`edu_calendar_body_id`        AS `edu_calendar_body_id`,
       `ecb`.`term`                        AS `term`,
       `ecb`.`part_one`                    AS `part_one`,
       `ecb`.`part_two`                    AS `part_two`,
       `ecb`.`term_occurance_acad_year_id` AS `term_occurance_acad_year_id`,
       `ecb`.`edu_calendar_id`             AS `edu_calendar_id`
from (((`epos`.`plan` `p` join `epos`.`plan_version` `pv` on (((`pv`.`plan_id` = `p`.`plan_id`) and
                                                               (`pv`.`effective` = (select max(`pv_max`.`effective`)
                                                                                    from `epos`.`plan_version` `pv_max`
                                                                                    where ((`pv`.`plan_id` = `pv_max`.`plan_id`) and
                                                                                           (`pv_max`.`effective` <= now())))) and
                                                               (`p`.`deleted` > now())))) join `epos`.`edu_calendar` `ec` on ((`ec`.`edu_calendar_id` = `pv`.`edu_calendar_id`)))
         join `epos`.`edu_calendar_body` `ecb` on ((`ecb`.`edu_calendar_id` = `ec`.`edu_calendar_id`)))
order by `p`.`plan_id`, `ecb`.`edu_calendar_id`, `ecb`.`term`;

