create
    definer = root@localhost function getStaff(staff_coeff decimal(10, 2), credits decimal(10, 2),
                                               rate_coeff decimal(10, 2), groupCount int,
                                               studentCount int) returns decimal(10, 5)
BEGIN
	declare staff decimal(10, 5) default 0;
    declare studentCountAdjustment decimal(10, 5) default 0;
    
	if ISNULL(groupCount) then 
		set groupCount = 0;
	end if;

	if ISNULL(studentCount) then 
		set studentCount = 0;
	end if;    

	if (groupCount = 0) then return 0; end if;
    if (studentCount = 0) then return 0; end if; 
    
    IF ((studentCount >= 1) and (studentCount <= 2)) THEN set studentCountAdjustment = 0.9;
		ELSEIF ((studentCount >= 3) and (studentCount <= 4)) THEN  set studentCountAdjustment = 0.91;
		ELSEIF ((studentCount >= 5) and (studentCount <= 6)) THEN  set studentCountAdjustment = 0.92;
		ELSEIF ((studentCount >= 7) and (studentCount <= 8)) THEN  set studentCountAdjustment = 0.93;
		ELSEIF ((studentCount >= 9) and (studentCount <= 10)) THEN  set studentCountAdjustment = 0.94;     
		ELSEIF ((studentCount >= 11) and (studentCount <= 12)) THEN  set studentCountAdjustment = 0.95;            
		ELSEIF ((studentCount >= 13) and (studentCount <= 14)) THEN  set studentCountAdjustment = 0.96;                    
		ELSEIF ((studentCount >= 15) and (studentCount <= 16)) THEN  set studentCountAdjustment = 0.97;                    
		ELSEIF ((studentCount >= 17) and (studentCount <= 18)) THEN  set studentCountAdjustment = 0.98;                    
		ELSEIF ((studentCount = 19)) THEN  set studentCountAdjustment = 0.99;                            
		ELSEIF ((studentCount = 20)) THEN  set studentCountAdjustment = 1;                                            
		ELSEIF ((studentCount >= 20) and (studentCount <= 26)) THEN  set studentCountAdjustment = 1.01;        
		ELSEIF ((studentCount = 27)) THEN  set studentCountAdjustment = 1.02;        
		ELSEIF ((studentCount = 28)) THEN  set studentCountAdjustment = 1.03;                
		ELSEIF ((studentCount = 29)) THEN  set studentCountAdjustment = 1.04;                        
		ELSEIF ((studentCount >= 30)) THEN  set studentCountAdjustment = 1.05;                                
		ELSE set studentCountAdjustment = 0;
	END IF;
  
	set staff = 
		(credits/60) 
		-- * staff_coeff -- data from speciality 
        * rate_coeff -- data from group 
		* studentCountAdjustment; -- student count adjuctment
	
RETURN staff;

END;

