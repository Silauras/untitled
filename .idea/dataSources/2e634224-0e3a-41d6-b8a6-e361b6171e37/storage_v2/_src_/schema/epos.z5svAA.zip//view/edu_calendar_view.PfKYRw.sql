create view edu_calendar_view as
select `ec`.`edu_calendar_id`   AS `edu_calendar_id`,
       `ec`.`edu_span`          AS `edu_span`,
       `ec`.`edu_type`          AS `edu_type`,
       `ec`.`student_type`      AS `student_type`,
       `ec`.`edu_language`      AS `edu_language`,
       `ec`.`enrollment_number` AS `enrollment_number`,
       `ec`.`enrollment_type`   AS `enrollment_type`,
       `ec`.`acad_year_id`      AS `acad_year_id`,
       `ec`.`acad_degree_id`    AS `acad_degree_id`,
       `ad`.`full_name`         AS `acad_degree_full_name`,
       `ad`.`short_name`        AS `acad_degree_short_name`,
       `ad`.`details`           AS `acad_degree_details`
from ((`epos`.`edu_calendar` `ec` join `epos`.`acad_year` `ay` on ((`ay`.`acad_year_id` = `ec`.`acad_year_id`)))
         join `epos`.`acad_degree` `ad` on ((`ad`.`acad_degree_id` = `ec`.`acad_degree_id`)))
order by `ay`.`year_number`, `ad`.`full_name`, `ec`.`edu_span`, `ec`.`student_type`, `ec`.`edu_language`,
         `ec`.`enrollment_number`, `ec`.`enrollment_type`;

