create
    definer = root@localhost function getLoad(lecture_hours int, lab_work_hours int, practical_work_hours int,
                                              calc_graph_work int, calc_work int, control_work int, course_work int,
                                              course_project int, test int, graded_test int, exam int, groupCount int,
                                              studentCount int) returns decimal(10, 2)
BEGIN
	declare loadHours decimal(10, 2) default 0;
    
	if ISNULL(groupCount) then 
		set groupCount = 0;
	end if;

	if ISNULL(studentCount) then 
		set studentCount = 0;
	end if;    

	if (groupCount = 0) then return 0; end if;
    if (studentCount = 0) then return 0; end if;

	set loadHours =
		lecture_hours
		+ lab_work_hours
		+ practical_work_hours
            
		+ (calc_graph_work*0.5*studentCount)
		+ (calc_work*0.5*studentCount)
		+ (control_work*0.25*studentCount)
        
        + (course_work * 3 * studentCount)
		+ (course_project * 4 * studentCount)
        
		+ (test*2*groupCount)
		+ (graded_test*2*groupCount)
		+ (exam*0.33*studentCount)+(exam*2*groupCount)        
       
        ;
        
	RETURN loadHours;
END;

