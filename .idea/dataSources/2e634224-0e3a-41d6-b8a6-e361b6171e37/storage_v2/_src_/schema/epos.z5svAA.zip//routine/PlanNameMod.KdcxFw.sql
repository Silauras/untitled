create
    definer = root@localhost function PlanNameMod(plan_name varchar(255), modifier varchar(255)) returns varchar(255)
BEGIN
	return concat(plan_name, " ", modifier);
RETURN 1;
END;

