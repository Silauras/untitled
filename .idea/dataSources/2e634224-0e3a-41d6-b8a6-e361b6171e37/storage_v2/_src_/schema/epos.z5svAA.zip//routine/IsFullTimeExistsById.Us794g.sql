create
    definer = root@localhost function IsFullTimeExistsById(vfull_time_id int) returns int
BEGIN
	declare full_time_exists integer default 0;

    select count(full_time_id)
    into full_time_exists
    from full_time
    where full_time_id = vfull_time_id;

	IF full_time_exists> 0 THEN
		return 1;
	else
		return 0;
	end if;
END;

