create
    definer = root@localhost function IsPlanExists(vplan_name varchar(255), vready int, vlockedout int,
                                                   vstart_year_id int, vedu_proposition_id int,
                                                   vedu_calendar_id int) returns int
BEGIN
	declare plan_exists integer default 0;

	select
	count(*)
    into plan_exists
	from
	plan p
		inner join plan_version pv
			on pv.plan_id = p.plan_id
				and pv.effective =
					(select max(effective)
						from plan_version pv_max
						where pv.plan_id = pv_max.plan_id
							and pv_max.effective <=now())
				and p.deleted > now()
	where
           pv.plan_name = vplan_name and
           pv.ready = vready and
           pv.lockedout = vlockedout and
           pv.start_year_id = vstart_year_id and
           pv.edu_proposition_id = vedu_proposition_id and
           pv.edu_calendar_id = vedu_calendar_id;

	IF plan_exists> 0 THEN
		return 1;
	else
		return 0;
	end if;
END;

