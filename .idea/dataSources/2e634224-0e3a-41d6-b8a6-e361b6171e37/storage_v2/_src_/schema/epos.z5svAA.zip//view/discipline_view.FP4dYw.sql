create view discipline_view as
select `epos`.`discipline`.`discipline_id` AS `discipline_id`,
       `epos`.`discipline`.`full_name`     AS `full_name`,
       `epos`.`discipline`.`short_name`    AS `short_name`,
       `epos`.`discipline`.`eng_name`      AS `eng_name`
from `epos`.`discipline`
order by `epos`.`discipline`.`full_name`, `epos`.`discipline`.`short_name`, `epos`.`discipline`.`eng_name`;

