create view full_time_body_view as
select `ft`.`full_time_id`                    AS `full_time_full_time_id`,
       `ft`.`created`                         AS `full_time_created`,
       `ft`.`deleted`                         AS `full_time_deleted`,
       `ft`.`plan_id`                         AS `plan_id`,
       `ftv`.`full_time_id`                   AS `full_time_id`,
       `ftv`.`effective`                      AS `effective`,
       `ftv`.`created`                        AS `created`,
       `ftv`.`term`                           AS `term`,
       `ftv`.`credits`                        AS `credits`,
       `ftv`.`lecture_per_week_first`         AS `lecture_per_week_first`,
       `ftv`.`lecture_per_week_second`        AS `lecture_per_week_second`,
       `ftv`.`lab_work_per_week_first`        AS `lab_work_per_week_first`,
       `ftv`.`lab_work_per_week_second`       AS `lab_work_per_week_second`,
       `ftv`.`practical_work_per_week_first`  AS `practical_work_per_week_first`,
       `ftv`.`practical_work_per_week_second` AS `practical_work_per_week_second`,
       `ftv`.`calc_graph_work`                AS `calc_graph_work`,
       `ftv`.`calc_work`                      AS `calc_work`,
       `ftv`.`control_work`                   AS `control_work`,
       `ftv`.`course_work`                    AS `course_work`,
       `ftv`.`course_project`                 AS `course_project`,
       `ftv`.`exam`                           AS `exam`,
       `ftv`.`graded_test`                    AS `graded_test`,
       `ftv`.`test`                           AS `test`,
       `ftv`.`lecture_hours_first`            AS `lecture_hours_first`,
       `ftv`.`lecture_hours_second`           AS `lecture_hours_second`,
       `ftv`.`lab_work_hours_first`           AS `lab_work_hours_first`,
       `ftv`.`lab_work_hours_second`          AS `lab_work_hours_second`,
       `ftv`.`practical_work_hours_first`     AS `practical_work_hours_first`,
       `ftv`.`practical_work_hours_second`    AS `practical_work_hours_second`,
       `ftv`.`lecture_hours`                  AS `lecture_hours`,
       `ftv`.`lab_work_hours`                 AS `lab_work_hours`,
       `ftv`.`practical_work_hours`           AS `practical_work_hours`,
       `ftv`.`credit_hours`                   AS `credit_hours`,
       `ftv`.`academic_hours`                 AS `academic_hours`,
       `ftv`.`independent_work_hours`         AS `independent_work_hours`,
       `ftv`.`cycle_id`                       AS `cycle_id`,
       `ftv`.`discipline_id`                  AS `discipline_id`,
       `ftv`.`department_reader_id`           AS `department_reader_id`,
       `ftv`.`mandatory_lock`                 AS `mandatory_lock`
from (`epos`.`full_time` `ft`
         join `epos`.`full_time_version` `ftv` on (((`ftv`.`full_time_id` = `ft`.`full_time_id`) and
                                                    (`ftv`.`effective` = (select max(`ftv_max`.`effective`)
                                                                          from `epos`.`full_time_version` `ftv_max`
                                                                          where ((`ftv`.`full_time_id` = `ftv_max`.`full_time_id`) and
                                                                                 (`ftv_max`.`effective` <= now())))) and
                                                    (`ft`.`deleted` > now()))));

