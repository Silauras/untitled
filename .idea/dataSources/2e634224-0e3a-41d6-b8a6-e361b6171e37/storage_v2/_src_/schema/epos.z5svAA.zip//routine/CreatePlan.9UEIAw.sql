create
    definer = root@localhost procedure CreatePlan(IN vplan_name varchar(255), IN vready int, IN vlockedout int,
                                                  IN vstart_year_id int, IN vedu_proposition_id int,
                                                  IN vedu_calendar_id int, OUT vplan_id int)
BEGIN
    DECLARE plan_exists integer default 0;
	DECLARE last_inserted_id integer default 0;

    START TRANSACTION;

		set vplan_id = 0;
		set plan_exists = isPlanExists(vplan_name, vready, vlockedout, vstart_year_id, vedu_proposition_id, vedu_calendar_id);
        if plan_exists = 0 then

				-- Insert data
				insert into plan (created, deleted)
				values(default, default);

				-- get last inserted id
				SET last_inserted_id = LAST_INSERT_ID();

			-- insert dependent data
			IF last_inserted_id > 0 THEN
			INSERT INTO plan_version(plan_id, effective, created, plan_name, ready, lockedout, start_year_id, edu_proposition_id, edu_calendar_id)
				VALUES(last_inserted_id, default, default, vplan_name, vready, vlockedout, vstart_year_id, vedu_proposition_id, vedu_calendar_id);
				-- commit
                set vplan_id = last_inserted_id;
				COMMIT;
			 ELSE
				set vplan_id = -1;
				ROLLBACK;
			END IF;
		end if;
END;

