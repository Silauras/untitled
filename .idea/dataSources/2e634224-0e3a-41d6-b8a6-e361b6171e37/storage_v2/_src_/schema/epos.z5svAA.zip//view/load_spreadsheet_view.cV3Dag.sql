create view load_spreadsheet_view as
select '***'                                                                                       AS `discipline_n`,
       `disc`.`full_name`                                                                          AS `discipline_full_name`,
       `fv`.`faculty_number`                                                                       AS `faculty_number`,
       `dv`.`department_number`                                                                    AS `department_number`,
       `getSpecialityName`(`ep`.`edu_proposition_id`)                                              AS `specialty_full_name`,
       `getCourse`(`ftv`.`term`)                                                                   AS `course`,
       `ftv`.`term`                                                                                AS `semester`,
       ifnull(`ag`.`group_name`, '---')                                                            AS `group_name`,
       '1'                                                                                         AS `group_count`,
       ifnull(`ag`.`student_count`, '---')                                                         AS `student_count`,
       `getSemesterHours`(`ecb`.`part_one`, `ftv`.`lecture_per_week_first`, `ecb`.`part_two`,
                          `ftv`.`lecture_per_week_second`)                                         AS `lecture_hours`,
       `ftv`.`lecture_per_week_first`                                                              AS `lecture_per_week_first`,
       `ftv`.`lecture_per_week_second`                                                             AS `lecture_per_week_second`,
       `getSemesterHours`(`ecb`.`part_one`, `ftv`.`lab_work_per_week_first`, `ecb`.`part_two`,
                          `ftv`.`lab_work_per_week_second`)                                        AS `lab_work_hours`,
       `ftv`.`lab_work_per_week_first`                                                             AS `lab_work_per_week_first`,
       `ftv`.`lab_work_per_week_second`                                                            AS `lab_work_per_week_second`,
       `getSemesterHours`(`ecb`.`part_one`, `ftv`.`practical_work_per_week_first`, `ecb`.`part_two`,
                          `ftv`.`practical_work_per_week_second`)                                  AS `practical_work_hours`,
       `ftv`.`practical_work_per_week_first`                                                       AS `practical_work_per_week_first`,
       `ftv`.`practical_work_per_week_second`                                                      AS `practical_work_per_week_second`,
       ((`getSemesterHours`(`ecb`.`part_one`, `ftv`.`lecture_per_week_first`, `ecb`.`part_two`,
                            `ftv`.`lecture_per_week_second`) +
         `getSemesterHours`(`ecb`.`part_one`, `ftv`.`lab_work_per_week_first`, `ecb`.`part_two`,
                            `ftv`.`lab_work_per_week_second`)) +
        `getSemesterHours`(`ecb`.`part_one`, `ftv`.`practical_work_per_week_first`, `ecb`.`part_two`,
                           `ftv`.`practical_work_per_week_second`))                                AS `study_hours`,
       (`getCreditHours`(`ftv`.`credits`) -
        ((`getSemesterHours`(`ecb`.`part_one`, `ftv`.`lecture_per_week_first`, `ecb`.`part_two`,
                             `ftv`.`lecture_per_week_second`) +
          `getSemesterHours`(`ecb`.`part_one`, `ftv`.`lab_work_per_week_first`, `ecb`.`part_two`,
                             `ftv`.`lab_work_per_week_second`)) +
         `getSemesterHours`(`ecb`.`part_one`, `ftv`.`practical_work_per_week_first`, `ecb`.`part_two`,
                            `ftv`.`practical_work_per_week_second`)))                              AS `independent_hours`,
       `getCreditHours`(`ftv`.`credits`)                                                           AS `credit_hours`,
       `ftv`.`credits`                                                                             AS `credits`,
       `ftv`.`calc_graph_work`                                                                     AS `calc_graph_work`,
       `ftv`.`calc_work`                                                                           AS `calc_work`,
       `ftv`.`control_work`                                                                        AS `control_work`,
       `ftv`.`course_work`                                                                         AS `course_work`,
       `ftv`.`course_project`                                                                      AS `course_project`,
       `ftv`.`test`                                                                                AS `test`,
       `ftv`.`graded_test`                                                                         AS `graded_test`,
       `ftv`.`exam`                                                                                AS `exam`,
       `getLoad`(`getSemesterHours`(`ecb`.`part_one`, `ftv`.`lecture_per_week_first`, `ecb`.`part_two`,
                                    `ftv`.`lecture_per_week_second`),
                 `getSemesterHours`(`ecb`.`part_one`, `ftv`.`lab_work_per_week_first`, `ecb`.`part_two`,
                                    `ftv`.`lab_work_per_week_second`),
                 `getSemesterHours`(`ecb`.`part_one`, `ftv`.`lab_work_per_week_first`, `ecb`.`part_two`,
                                    `ftv`.`practical_work_per_week_second`), `ftv`.`calc_graph_work`, `ftv`.`calc_work`,
                 `ftv`.`control_work`, `ftv`.`course_work`, `ftv`.`course_project`, `ftv`.`test`, `ftv`.`graded_test`,
                 `ftv`.`exam`, 1, `ag`.`student_count`)                                            AS `total_load`,
       `getStaff`(`ep`.`staff_coeff`, `ftv`.`credits`, `ag`.`rate_coeff`, 1, `ag`.`student_count`) AS `staff`,
       `dreadv`.`department_number`                                                                AS `department_reader_number`,
       `ep`.`edu_span`                                                                             AS `edu_span`,
       `ep`.`edu_type`                                                                             AS `edu_type`,
       `ep`.`student_type`                                                                         AS `student_type`,
       `ep`.`edu_language`                                                                         AS `edu_language`,
       `ep`.`enrollment_number`                                                                    AS `enrollment_number`,
       `ep`.`enrollment_type`                                                                      AS `enrollment_type`,
       `ep`.`staff_coeff`                                                                          AS `staff_coeff`,
       `pv`.`ready`                                                                                AS `plan_ready`,
       `ecb`.`term_occurance_acad_year_id`                                                         AS `start_year_id`,
       `ep`.`edu_proposition_id`                                                                   AS `edu_proposition_id`,
       `disc`.`discipline_id`                                                                      AS `discipline_id`,
       `dread`.`department_id`                                                                     AS `department_reader_id`,
       `pv`.`plan_id`                                                                              AS `plan_id`,
       `ftv`.`full_time_id`                                                                        AS `full_time_id`,
       `ag`.`acad_group_id`                                                                        AS `group_id`,
       `ag`.`current_year_id`                                                                      AS `group_current_year_id`,
       '***'                                                                                       AS `***`
from (((((((((((((((((`epos`.`plan` `p` join `epos`.`plan_version` `pv` on (((`pv`.`plan_id` = `p`.`plan_id`) and
                                                                             (`pv`.`effective` =
                                                                              (select max(`pv_max`.`effective`)
                                                                               from `epos`.`plan_version` `pv_max`
                                                                               where ((`pv`.`plan_id` = `pv_max`.`plan_id`) and
                                                                                      (`pv_max`.`effective` <= now())))) and
                                                                             (`p`.`deleted` > now())))) join `epos`.`full_time` `ft` on ((`ft`.`plan_id` = `p`.`plan_id`))) join `epos`.`full_time_version` `ftv` on ((
        (`ftv`.`full_time_id` = `ft`.`full_time_id`) and (`ftv`.`effective` = (select max(`ftv_max`.`effective`)
                                                                               from `epos`.`full_time_version` `ftv_max`
                                                                               where ((`ftv`.`full_time_id` = `ftv_max`.`full_time_id`) and
                                                                                      (`ftv_max`.`effective` <= now())))) and
        (`ft`.`deleted` > now())))) join `epos`.`discipline` `disc` on ((`disc`.`discipline_id` = `ftv`.`discipline_id`))) join `epos`.`department` `dread` on ((`dread`.`department_id` = `ftv`.`department_reader_id`))) join `epos`.`department_version` `dreadv` on ((
        (`dreadv`.`department_id` = `dread`.`department_id`) and
        (`dreadv`.`effective` = (select max(`dreadv_max`.`effective`)
                                 from `epos`.`department_version` `dreadv_max`
                                 where ((`dreadv`.`department_id` = `dreadv_max`.`department_id`) and
                                        (`dreadv_max`.`effective` <= now())))) and
        (`dread`.`deleted` > now())))) join `epos`.`edu_proposition` `ep` on ((`ep`.`edu_proposition_id` = `pv`.`edu_proposition_id`))) join `epos`.`department` `d` on ((`d`.`department_id` = `ep`.`department_id`))) join `epos`.`department_version` `dv` on ((
        (`dv`.`department_id` = `d`.`department_id`) and (`dv`.`effective` = (select max(`dv_max`.`effective`)
                                                                              from `epos`.`department_version` `dv_max`
                                                                              where ((`dv`.`department_id` = `dv_max`.`department_id`) and
                                                                                     (`dv_max`.`effective` <= now())))) and
        (`d`.`deleted` > now())))) join `epos`.`faculty` `f` on ((`f`.`faculty_id` = `dv`.`faculty_id`))) join `epos`.`faculty_version` `fv` on ((
        (`fv`.`faculty_id` = `f`.`faculty_id`) and (`fv`.`effective` = (select max(`fv_max`.`effective`)
                                                                        from `epos`.`faculty_version` `fv_max`
                                                                        where ((`fv`.`faculty_id` = `fv_max`.`faculty_id`) and
                                                                               (`fv_max`.`effective` <= now())))) and
        (`f`.`deleted` > now())))) join `epos`.`direction` `dir` on ((`ep`.`direction_id` = `dir`.`direction_id`))) join `epos`.`speciality` `sp` on ((`sp`.`speciality_id` = `ep`.`speciality_id`))) join `epos`.`edu_program` `eprog` on ((`eprog`.`edu_program_id` = `ep`.`edu_program_id`))) join `epos`.`edu_calendar` `ec` on ((`ec`.`edu_calendar_id` = `pv`.`edu_calendar_id`))) join `epos`.`edu_calendar_body` `ecb` on ((
        (`ecb`.`edu_calendar_id` = `ec`.`edu_calendar_id`) and (`ecb`.`term` = `ftv`.`term`))))
         left join `epos`.`acad_group` `ag` on (((`ag`.`edu_proposition_id` = `ep`.`edu_proposition_id`) and
                                                 (`getCourse`(`ftv`.`term`) = `ag`.`course`))))
order by `ep`.`edu_type`, `ep`.`student_type`, `ep`.`edu_language`, `ep`.`enrollment_number`, `ep`.`enrollment_type`,
         `dv`.`department_number`, `dir`.`direction_code`, `sp`.`speciality_code`, `eprog`.`full_name`, `ep`.`edu_span`,
         `ag`.`group_name`, `ftv`.`term`, `disc`.`full_name`;

