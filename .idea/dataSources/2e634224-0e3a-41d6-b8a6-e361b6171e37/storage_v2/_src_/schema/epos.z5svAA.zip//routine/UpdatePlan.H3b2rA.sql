create
    definer = root@localhost procedure UpdatePlan(IN vplan_id int, IN vplan_name varchar(255), IN vready int,
                                                  IN vlockedout int, IN vstart_year_id int, IN vedu_proposition_id int,
                                                  IN vedu_calendar_id int, OUT update_state int)
BEGIN

    DECLARE plan_exists integer default 0;
	DECLARE updated_rows integer default 0;

    declare created_time datetime(6) DEFAULT CURRENT_TIMESTAMP(6);
    declare effective_time datetime(6) DEFAULT CURRENT_TIMESTAMP(6);

	set update_state = 0;

	START TRANSACTION;
		set plan_exists = IsPlanExistsById(vplan_id);

		if plan_exists = 1 then

			select created into created_time from plan where plan_id = vplan_id;
			set effective_time = CURRENT_TIMESTAMP(6);

				-- update data
			INSERT INTO plan_version(plan_id, effective, created, plan_name, ready, lockedout, start_year_id, edu_proposition_id, edu_calendar_id)
				VALUES(vplan_id, effective_time, created_time, vplan_name, vready, vlockedout, vstart_year_id, vedu_proposition_id, vedu_calendar_id);

                -- check for changes in database
                set update_state = ROW_COUNT();

			-- if only 1 updated then everything is fine
			IF update_state = 1 THEN
				COMMIT;
			 ELSE
				ROLLBACK;
			END IF;
		end if;
END;

