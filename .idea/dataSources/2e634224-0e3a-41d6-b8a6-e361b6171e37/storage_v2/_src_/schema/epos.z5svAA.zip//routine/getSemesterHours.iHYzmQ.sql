create
    definer = root@localhost function getSemesterHours(first_part_length int, first_part_hours int,
                                                       second_part_length int, second_part_hours int) returns int
BEGIN
	RETURN ((first_part_length * first_part_hours) + (second_part_length * second_part_hours));
END;

