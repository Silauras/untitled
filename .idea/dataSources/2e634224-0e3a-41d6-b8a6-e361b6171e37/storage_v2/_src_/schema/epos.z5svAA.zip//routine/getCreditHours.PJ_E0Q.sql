create
    definer = root@localhost function getCreditHours(credits decimal(10, 2)) returns decimal(10, 2)
BEGIN
	declare creditHours decimal(10, 2) default 30;	
	RETURN (credits * creditHours);
END;

