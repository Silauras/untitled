create
    definer = root@localhost function getSpecialityName(edu_proposition_id int) returns varchar(255)
BEGIN
	declare specialityFullName varchar(255) default "";

		declare acadDegree varchar(255) default "";
        declare specialityCode varchar(255) default "";
		declare eduProgram varchar(255) default "";
	
		declare eduSpan varchar(255) default "";
		declare eduType varchar(255) default "";
		declare studentType varchar(255) default "";
		declare eduLanguage varchar(255) default "";
		declare enrollmentNumber varchar(255) default "";
		declare enrollmentType varchar(255) default "";

        declare customPrefix varchar(255) default "";

	select 
		ad.full_name, 
		sp.speciality_code,
		eprog.full_name,
			ep.edu_span,
			ep.edu_type,
			ep.student_type,
			ep.edu_language,
			ep.enrollment_number,
			ep.enrollment_type
	into
		acadDegree,
		specialityCode,
		eduProgram,
			eduSpan,
			eduType,
			studentType,
			eduLanguage,
			enrollmentNumber,
			enrollmentType
	from
		edu_proposition ep
		inner join acad_degree ad
			on ep.acad_degree_id = ad.acad_degree_id
		inner join direction dir
			on ep.direction_id = dir.direction_id
		inner join speciality sp
			on sp.speciality_id = ep.speciality_id
		inner join edu_program eprog
			on eprog.edu_program_id = ep.edu_program_id
	where ep.edu_proposition_id = edu_proposition_id;

    IF (acadDegree = "Бакалавр")  THEN set acadDegree = "6";
		ELSEIF (acadDegree = "Магістр")  THEN set acadDegree = "8";
		ELSEIF (acadDegree = "Аспірант")  THEN set acadDegree = "9";                        
		ELSE set acadDegree = "0";
	END IF;
 
	if    
	(
	(eduType = "очна форма навчання") and 
	(studentType = "український студент") and 
	(eduLanguage = "українська мова") and 
	(enrollmentNumber = "1 набір") and 
	(enrollmentType = "ХАІ")
	)
	then set customPrefix = "(У)";
    ELSEIF 
	(
	(eduType = "очна форма навчання") and 
	(studentType = "іноземний студент") and 
	(eduLanguage = "українська мова") and 
	(enrollmentNumber = "1 набір") and 
	(enrollmentType = "ХАІ")
	)    
    then set customPrefix = "(ІНУМ)";
    ELSEIF 
	(
	(eduType = "очна форма навчання") and 
	(studentType = "іноземний студент") and 
	(eduLanguage = "англійська мова") and 
	(enrollmentNumber = "1 набір") and 
	(enrollmentType = "ХАІ")
	)    
    then set customPrefix = "(ІНАМ)";		
    ELSEIF 
	(
	(eduType = "очна форма навчання") and 
	(studentType = "іноземний студент") and 
	(eduLanguage = "англійська мова") and 
	(enrollmentNumber = "2 набір") and 
	(enrollmentType = "ХАІ")
	)    
    then set customPrefix = "(ІНАМ2Н)";		    
    ELSEIF 
	(
	(eduType = "очна форма навчання") and 
	(studentType = "український аспірант") and 
	(eduLanguage = "українська мова") and 
	(enrollmentNumber = "1 набір") and 
	(enrollmentType = "ХАІ")
	)    
    then set customPrefix = "(АСП)";
    ELSEIF 
	(
	(eduType = "очна форма навчання") and 
	(studentType = "іноземний аспірант") and 
	(eduLanguage = "українська мова") and 
	(enrollmentNumber = "1 набір") and 
	(enrollmentType = "ХАІ")
	)    
    then set customPrefix = "(AІНУМ)";
    ELSEIF 
	(
	(eduType = "очна форма навчання") and 
	(studentType = "іноземний аспірант") and 
	(eduLanguage = "англійська мова") and 
	(enrollmentNumber = "1 набір") and 
	(enrollmentType = "ХАІ")
	)    
    then set customPrefix = "(AІНАМ)";
    ELSEIF 
	(
	(eduType = "очна форма навчання") and 
	(studentType = "український студент") and 
	(eduLanguage = "українська мова") and 
	(enrollmentNumber = "1 набір") and 
	(enrollmentType = "КИЇВ")
	)
	then set customPrefix = "(КИЇВ)";    
    ELSEIF 
	(
	(eduType = "очна форма навчання") and 
	(studentType = "китайський студент") and 
	(eduLanguage = "українська мова") and 
	(enrollmentNumber = "1 набір") and 
	(enrollmentType = "ХАІ")
	)    
    then set customPrefix = "(КИТАЙ)";    

    end if;
 
    set specialityFullName = concat(acadDegree, ".", specialityCode, " (", eduProgram, ") ", "(", eduSpan, ") ",  customPrefix);
    
RETURN specialityFullName;

END;

