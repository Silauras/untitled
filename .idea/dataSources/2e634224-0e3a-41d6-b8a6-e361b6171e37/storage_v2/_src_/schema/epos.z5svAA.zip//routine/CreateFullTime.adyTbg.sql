create
    definer = root@localhost procedure CreateFullTime(IN vplan_id int, IN vterm smallint, IN vcredits decimal(10, 2),
                                                      IN vlecture_per_week_first smallint,
                                                      IN vlecture_per_week_second smallint,
                                                      IN vlab_work_per_week_first smallint,
                                                      IN vlab_work_per_week_second smallint,
                                                      IN vpractical_work_per_week_first smallint,
                                                      IN vpractical_work_per_week_second smallint,
                                                      IN vcalc_graph_work smallint, IN vcalc_work smallint,
                                                      IN vcontrol_work smallint, IN vcourse_work smallint,
                                                      IN vcourse_project smallint, IN vexam smallint,
                                                      IN vgraded_test smallint, IN vtest smallint,
                                                      IN vlecture_hours_first smallint,
                                                      IN vlecture_hours_second smallint,
                                                      IN vlab_work_hours_first smallint,
                                                      IN vlab_work_hours_second smallint,
                                                      IN vpractical_work_hours_first smallint,
                                                      IN vpractical_work_hours_second smallint,
                                                      IN vlecture_hours smallint, IN vlab_work_hours smallint,
                                                      IN vpractical_work_hours smallint, IN vcredit_hours smallint,
                                                      IN vacademic_hours smallint, IN vindependent_work_hours smallint,
                                                      IN vcycle_id int, IN vdiscipline_id int,
                                                      IN vdepartment_reader_id int, IN vmandatory_lock int,
                                                      OUT vfull_time_id int)
BEGIN
    #DECLARE plan_exists integer default 0;
	DECLARE last_inserted_id integer default 0;
    declare created_time datetime(6) DEFAULT CURRENT_TIMESTAMP(6);
    declare deleted_time datetime(6) DEFAULT '9999-12-31 23:59:59.000000';
    declare effective_time datetime(6) DEFAULT CURRENT_TIMESTAMP(6);

    START TRANSACTION;
		-- Insert data for a full_time

        set created_time = CURRENT_TIMESTAMP(6);
        set deleted_time = '9999-12-31 23:59:59.000000';
		set effective_time = created_time;

		insert into full_time (created, deleted, plan_id)
		values(created_time, deleted_time, vplan_id);

		-- get last inserted id
		SET last_inserted_id = LAST_INSERT_ID();

		-- insert dependent data
			IF last_inserted_id > 0 THEN

                insert into full_time_version(full_time_id, effective, created, term, credits, lecture_per_week_first, lecture_per_week_second, lab_work_per_week_first, lab_work_per_week_second, practical_work_per_week_first, practical_work_per_week_second, calc_graph_work, calc_work, control_work, course_work, course_project, exam, graded_test, test, lecture_hours_first, lecture_hours_second, lab_work_hours_first, lab_work_hours_second, practical_work_hours_first, practical_work_hours_second, lecture_hours, lab_work_hours, practical_work_hours, credit_hours, academic_hours, independent_work_hours, cycle_id, discipline_id, department_reader_id, mandatory_lock)
                values(last_inserted_id, effective_time, created_time, vterm, vcredits, vlecture_per_week_first, vlecture_per_week_second, vlab_work_per_week_first, vlab_work_per_week_second, vpractical_work_per_week_first, vpractical_work_per_week_second, vcalc_graph_work, vcalc_work, vcontrol_work, vcourse_work, vcourse_project, vexam, vgraded_test, vtest, vlecture_hours_first, vlecture_hours_second, vlab_work_hours_first, vlab_work_hours_second, vpractical_work_hours_first, vpractical_work_hours_second, vlecture_hours, vlab_work_hours, vpractical_work_hours, vcredit_hours, vacademic_hours, vindependent_work_hours, vcycle_id, vdiscipline_id, vdepartment_reader_id, vmandatory_lock);
				-- commit
                set vfull_time_id = last_inserted_id;
				COMMIT;
			 ELSE
				set vfull_time_id = -1;
				ROLLBACK;
			END IF;

END;

